package com.example.aidrummer

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private lateinit var engine: DrumEngine
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) engine.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DrumEngine()
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(false) }
                var bpm by remember { mutableIntStateOf(0) }
                var style by remember { mutableStateOf(DrumStyle.ROCK) }
                var section by remember { mutableStateOf(Section.VERSE) }
                var fillAmount by remember { mutableFloatStateOf(0.55f) }
                LaunchedEffect(Unit) {
                    while (true) {
                        bpm = engine.tempoBpm
                        running = engine.isRunning
                        delay(250)
                    }
                }
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("AI DRUMMER", style = MaterialTheme.typography.headlineLarge)
                    Text("Kitaristin mukana soittava rumpaliprototyyppi")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (running) "KUUNTELEE KITARAA" else "VALMIINA", style = MaterialTheme.typography.titleMedium)
                            Text(if (bpm > 0) "$bpm BPM" else "Tempoa ei vielä tunnistettu", style = MaterialTheme.typography.headlineMedium)
                            Text("Vinkki: soita selkeitä, tasaisia iskuja puhelimen lähellä.")
                        }
                    }
                    Button(onClick = {
                        if (running) engine.stop()
                        else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) engine.start()
                        else permission.launch(Manifest.permission.RECORD_AUDIO)
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "PYSÄYTÄ" else "ALOITA KUUNTELU") }

                    Text("Rumpalin tyyli", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DrumStyle.values().forEach { item -> FilterChip(selected = style == item, onClick = { style = item; engine.style = item }, label = { Text(item.label) }) }
                    }
                    Text("Kappaleen osa", style = MaterialTheme.typography.titleLarge)
                    Text("Voit ohjata rakennetta käsin. Automaattinen rakenteentunnistus lisätään seuraavaan kehitysvaiheeseen.")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Section.values().forEach { item ->
                            OutlinedButton(onClick = { section = item; engine.section = item }, modifier = Modifier.fillMaxWidth()) { Text(if (section == item) "● ${item.label}" else item.label) }
                        }
                    }
                    Text("Fillien määrä: ${(fillAmount * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
                    Slider(value = fillAmount, onValueChange = { fillAmount = it; engine.fillProbability = it }, valueRange = 0f..1f)
                    Text("Tämä on ensimmäinen tekninen prototyyppi. Se tunnistaa iskujen ajoitusta ja tuottaa synteettisen rumpukompin. Musiikillinen rakenteentunnistus, luonnolliset rumpusamplet ja kehittyneet fillit vaativat seuraavat kehitysvaiheet.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    override fun onDestroy() { if (::engine.isInitialized) engine.stop(); super.onDestroy() }
}

enum class DrumStyle(val label: String) { ROCK("Rock"), BLUES("Blues"), METAL("Metal") }
enum class Section(val label: String) { INTRO("Intro"), VERSE("Säkeistö"), CHORUS("Kertosäe"), SOLO("Soolo"), BREAK("Välisoitto"), ENDING("Lopetus") }

/** Lightweight MVP: mic onset/tempo tracking + synthesized drum output. */
class DrumEngine {
    @Volatile var isRunning = false; private set
    @Volatile var tempoBpm = 0; private set
    @Volatile var style = DrumStyle.ROCK
    @Volatile var section = Section.VERSE
    @Volatile var fillProbability = 0.55f
    private var recorder: AudioRecord? = null
    private var inputThread: Thread? = null
    private var outputThread: Thread? = null
    private val sampleRate = 44100
    @Volatile private var lastOnsetNs = 0L
    @Volatile private var beatPeriodNs = 600_000_000L
    @Volatile private var lastBeatNs = 0L
    private val intervals = ArrayDeque<Long>()

    @Synchronized fun start() {
        if (isRunning) return
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return
        val r = AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return }
        recorder = r; isRunning = true; r.startRecording()
        inputThread = Thread { analyzeLoop(r) }.also { it.start() }
        outputThread = Thread { drumLoop() }.also { it.start() }
    }

    @Synchronized fun stop() {
        isRunning = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { inputThread?.join(300) } catch (_: Exception) {}
        try { outputThread?.join(300) } catch (_: Exception) {}
        recorder?.release(); recorder = null
    }

    private fun analyzeLoop(r: AudioRecord) {
        val data = ShortArray(1024)
        var noiseFloor = 250.0
        var previousRms = 0.0
        while (isRunning) {
            val n = r.read(data, 0, data.size)
            if (n <= 0) continue
            var sum = 0.0
            for (i in 0 until n) { val v = data[i].toDouble(); sum += v * v }
            val rms = sqrt(sum / n)
            noiseFloor = noiseFloor * 0.985 + minOf(rms, noiseFloor * 1.4) * 0.015
            val now = System.nanoTime()
            val threshold = maxOf(650.0, noiseFloor * 2.25)
            if (rms > threshold && previousRms < threshold * 0.8 && now - lastOnsetNs > 125_000_000L) {
                val prev = lastOnsetNs
                lastOnsetNs = now
                if (prev > 0) {
                    val raw = now - prev
                    // Map detected subdivisions to a plausible quarter-note tempo.
                    val candidates = listOf(raw, raw * 2, raw * 3 / 2, raw / 2)
                    val plausible = candidates.filter { it in 250_000_000L..1_200_000_000L }
                    if (plausible.isNotEmpty()) {
                        val chosen = plausible.minByOrNull { abs(it - beatPeriodNs) } ?: plausible.first()
                        intervals.addLast(chosen); while (intervals.size > 6) intervals.removeFirst()
                        val sorted = intervals.sorted()
                        beatPeriodNs = sorted[sorted.size / 2]
                        tempoBpm = (60_000_000_000.0 / beatPeriodNs).toInt().coerceIn(50, 240)
                    }
                }
            }
            previousRms = rms
        }
    }

    private fun drumLoop() {
        val min = android.media.AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = android.media.AudioTrack(android.media.AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096), android.media.AudioTrack.MODE_STREAM)
        if (track.state != android.media.AudioTrack.STATE_INITIALIZED) { track.release(); return }
        track.play()
        val block = ShortArray(256)
        val kick = DrumVoice(sampleRate, 1); val snare = DrumVoice(sampleRate, 2); val hat = DrumVoice(sampleRate, 3)
        var nextBeat = 0L; var beat = 0L; var step = 0
        while (isRunning) {
            val now = System.nanoTime()
            val period = beatPeriodNs
            if (tempoBpm > 0 && now >= nextBeat) {
                val barBeat = (beat % 4).toInt()
                val loud = if (section == Section.CHORUS || section == Section.SOLO) 1.0 else 0.78
                val isMetal = style == DrumStyle.METAL
                if (barBeat == 0 || (isMetal && barBeat == 2)) kick.trigger(if (isMetal) 1.0 else loud)
                if (barBeat == 1 || barBeat == 3) snare.trigger(loud)
                hat.trigger(if (section == Section.INTRO) 0.35 else 0.55)
                // Simple fill at the end of every fourth bar, with more activity in solo/break.
                val fillChance = fillProbability * if (section == Section.SOLO || section == Section.BREAK) 1.35f else 1f
                if (beat > 0 && beat % 16L == 15L && Math.random() < fillChance) snare.trigger(0.9)
                lastBeatNs = now; nextBeat = now + period; beat++; step++
            }
            for (i in block.indices) {
                var x = kick.next() + snare.next() + hat.next()
                x = x.coerceIn(-1.0, 1.0)
                block[i] = (x * 26000).toInt().toShort()
            }
            track.write(block, 0, block.size)
        }
        track.stop(); track.release()
    }
}

private class DrumVoice(private val rate: Int, private val kind: Int) {
    private var phase = 0.0; private var age = 0; private var length = 0; private var level = 0.0
    fun trigger(volume: Double) { age = 0; length = when (kind) { 1 -> 9000; 2 -> 7500; else -> 3000 }; level = volume }
    fun next(): Double {
        if (age >= length || length == 0) return 0.0
        val t = age.toDouble() / rate
        val env = kotlin.math.exp(-t * when (kind) { 1 -> 13.0; 2 -> 22.0; else -> 48.0 })
        val value = if (kind == 1) {
            val f = 95.0 * kotlin.math.exp(-t * 9.0) + 42.0
            phase += 2.0 * Math.PI * f / rate
            kotlin.math.sin(phase) * env
        } else {
            // Noise-like snare/hat transient from a deterministic high-frequency oscillator mix.
            phase += 2.0 * Math.PI * (if (kind == 2) 7300.0 else 10500.0) / rate
            (kotlin.math.sin(phase) * 0.55 + kotlin.math.sin(phase * 1.713) * 0.3) * env
        }
        age++
        return value * level * when (kind) { 1 -> 0.9; 2 -> 0.35; else -> 0.16 }
    }
}
