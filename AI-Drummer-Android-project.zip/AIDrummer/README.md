# AI Drummer – Android-prototyyppi 0.1

Tämä on Android-sovelluksen ensimmäinen lähdekoodiprototyyppi. Se on suunniteltu Redmi Note 11 Pro 5G -puhelimelle, mutta toimii Android 8.0+ -laitteissa.

## Mitä prototyyppi tekee nyt
- Pyytää mikrofoniluvan ja kuuntelee ääntä paikallisesti puhelimessa.
- Analysoi äänen voimakkuusmuutoksia ja arvioi niiden perusteella tempoa.
- Näyttää arvioidun BPM-luvun.
- Tuottaa yksinkertaiset synteettiset bassorumpu-, virveli- ja hi-hat-äänet.
- Sisältää Rock-, Blues- ja Metal-valinnat.
- Sisältää manuaaliset osavalinnat: intro, säkeistö, kertosäe, soolo, välisoitto ja lopetus.
- Sisältää fillien määrän säätimen.

## Mitä se EI vielä tee
Tämä ei ole valmis älykäs virtuaalirumpali. Äänenvoimakkuuteen perustuva iskujen tunnistus on karkea: se voi tulkita kitaran yksittäisiä kieli-iskuja, sointujen vaihtoja tai kaiuttimesta kuuluvia rumpuja väärin. Rumpukomppi on yksinkertainen ja filli on vasta paikkamerkkitoteutus.

Seuraavat kehitysvaiheet ovat:
1. Parempi kitaran transientti- ja tahtitunnistus.
2. Kaiuttimen äänen vaikutuksen vähentäminen mikrofonitulosta.
3. Luonnolliset rumpusamplet ja oikea fillikirjasto.
4. Fraasien tunnistus ja kitaristin soittoon vastaaminen.
5. Automaattinen kappalerakenteen tunnistus.

## APK:n rakentaminen ilman omaa tietokonetta

Projektissa on GitHub Actions -työnkulku, joka voi rakentaa APK:n GitHubissa.

1. Luo GitHub-tili, jos sinulla ei vielä ole sellaista.
2. Luo GitHubissa uusi tyhjä repository nimeltä `AI-Drummer`.
3. Lataa tämän ZIP-paketin sisältö puhelimeen ja pura se.
4. GitHubin selaimessa avaa repository ja valitse **Add file → Upload files**. Lataa puretun `AIDrummer`-kansion SISÄLTÖ (myös `.github`-kansio) repositoryn juureen ja tee commit.
5. Avaa repositoryn **Actions**-välilehti. Valitse **Build Android APK** ja tarvittaessa **Run workflow**.
6. Kun ajo valmistuu vihreäksi, avaa ajon sivu ja lataa **AI-Drummer-debug-apk** kohdasta Artifacts.
7. Avaa ladattu APK Redmi-puhelimessa ja salli tarvittaessa selaimelle/tiedostonhallinnalle sovellusten asennus tuntemattomista lähteistä.

APK:n asennus saattaa vaatia Androidin vahvistuksen. Asenna vain itse rakentamasi paketti omasta GitHub-repositorystasi.

## Testaus kaiuttimella
Aloita hiljaisella kaiutinvoimakkuudella. Aseta puhelin lähelle kitaraa mutta älä aivan kaiuttimen viereen. Koska sama puhelin kuuntelee kitaraa ja soittaa rumpuja, kaiuttimen rumpuääni voi sekoittaa tunnistusta. Tämä on yksi ensimmäisen prototyypin tärkeimmistä teknisistä rajoitteista.

## Kehitysympäristö
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Android SDK 35
- Minimi Android 8.0 (API 26)

Sovelluksen pakettitunnus: `com.example.aidrummer`
