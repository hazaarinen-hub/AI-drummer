# AI Drummer – Android-prototyyppi 0.3

AI Drummer kuuntelee kitaransoittoa puhelimen mikrofonilla, arvioi soiton tempoa ja soittaa sen mukana rumpukompin.

## Versio 0.3
- Tempon arvioinnissa käytetään enintään yhdeksän viimeisimmän kelvollisen iskuvälin liukuvaa mediaania.
- Tempon muutosta suodatetaan ja suuria muutoksia hyväksytään vasta useamman peräkkäisen havainnon jälkeen. Tämä vähentää yksittäisten iskujen aiheuttamaa BPM:n aaltoilua.
- Rumpukomppi ajoitetaan kahdeksasosapulssilla, eikä yksittäinen kitaranisku suoraan siirrä seuraavaa rumpuiskua.
- Rumpuäänissä on aiempaa monipuolisempi synteettinen mallinnus: bassorummun sävelkorkeuden lasku, virvelin kohina ja runko, suljettu/avoin hi-hat, kolme tomia, crash ja ride.
- Rock-, Blues- ja Metal-tyyleillä on erilaiset komppikuviot.
- Fillisäätö vaikuttaa neljän tahdin jakson viimeisen tahdin rumpufillin todennäköisyyteen.
- Kappaleen osan valinta muuttaa dynamiikkaa ja soiton tiheyttä. Osien automaattista tunnistusta ei vielä ole.
- Äänen ulostulon valinta ja suomenkielinen käyttöohje säilyvät.

## Käyttöohje
1. Avaa AI Drummer ja valitse Äänen ulostulo -kohdasta Automaattinen, Puhelin tai Bluetooth.
2. Paina ALOITA KUUNTELU ja hyväksy mikrofonilupa.
3. Soita selkeitä, tasaisia iskuja mikrofonin lähellä, jotta sovellus voi arvioida tempon. Anna sovellukselle muutama isku ennen kuin arvio vakiintuu.
4. Valitse Rock, Blues tai Metal.
5. Valitse kappaleen osa: Intro, Säkeistö, Kertosäe, Soolo, Välisoitto tai Lopetus.
6. Säädä Fillien määrä -liukusäätimellä neljän tahdin jakson lopussa tulevien fillien todennäköisyyttä.
7. Paina PYSÄYTÄ lopettaaksesi kuuntelun ja rumpujen soiton.
8. Avaa OHJE-painike saadaksesi painikkeiden tarkemmat selitykset.

## Äänet ja tunnetut rajoitteet
Rumpuäänet ovat tässä versiossa sovelluksessa laskennallisesti tuotettuja synteettisiä ääniä, eivät vielä oikeista rumpuäänityksistä tehtyjä sampleja. Tämä versio parantaa äänten sävyä ja vaihtelua, mutta luonnollinen rumpusamplekirjasto on erillinen seuraava kehitysvaihe.

Tempon tunnistus perustuu mikrofonitulon voimakkuusmuutoksiin. Se voi erehtyä esimerkiksi sointujen vaihdoista, taustamelusta tai puhelimen omasta rumpuäänestä. Liukuva puskuri ja suodatus vähentävät heilahtelua, mutta eivät poista virhetunnistuksia kokonaan. Sovellus ei vielä tunnista tahtilajia eikä kappaleen rakennetta automaattisesti. Kappaleen osat valitaan käsin.

Bluetooth voi lisätä huomattavan ääniviiveen. Kitaristin kanssa reaaliaikaisesti soitettaessa puhelimen kaiutin tai mahdollisimman viiveetön langallinen ulostulo on yleensä parempi.

## APK:n rakentaminen GitHub Actionsilla
1. Pura ZIP-paketti.
2. Lataa puretun `AIDrummer`-kansion sisältö GitHub-repositorion juureen (myös `.github`-kansio).
3. Avaa GitHubin Actions-välilehti ja käynnistä Build Android APK -työnkulku.
4. Kun ajo onnistuu, avaa työnkulun ajo ja lataa APK kohdasta Artifacts.
5. Siirrä APK puhelimeen, avaa se ja hyväksy tarvittaessa sovellusten asennus kyseisestä lähteestä.

## Kehitysympäristö
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Android SDK 35
- Minimi Android 8.0 (API 26)
- Sovellustunnus: `com.example.aidrummer`
- Sovellusversio: `0.3`
