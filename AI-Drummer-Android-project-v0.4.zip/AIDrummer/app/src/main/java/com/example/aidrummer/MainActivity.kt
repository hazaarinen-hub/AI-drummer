package com.example.aidrummer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private lateinit var engine: DrumEngine
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) engine.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DrumEngine(this)
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(false) }
                var bpm by remember { mutableIntStateOf(100) }
                var tempoDetected by remember { mutableStateOf(false) }
                var style by remember { mutableStateOf(DrumStyle.ROCK) }
                var section by remember { mutableStateOf(Section.VERSE) }
                var fillAmount by remember { mutableFloatStateOf(0.55f) }
                var output by remember { mutableStateOf(OutputTarget.AUTO) }
                var routeStatus by remember { mutableStateOf("Automaattinen äänireititys") }
                var showHelp by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    while (true) {
                        bpm = engine.tempoBpm
                        running = engine.isRunning
                        tempoDetected = engine.tempoDetected
                        routeStatus = engine.routeStatus
                        delay(250)
                    }
                }

                if (showHelp) {
                    AlertDialog(
                        onDismissRequest = { showHelp = false },
                        confirmButton = { TextButton(onClick = { showHelp = false }) { Text("SULJE") } },
                        title = { Text("AI Drummer – käyttöohje") },
                        text = {
                            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                HelpItem("Aloita kuuntelu", "Pyytää mikrofoniluvan tarvittaessa. Sovellus kuuntelee kitaran iskuja ja arvioi niiden perusteella tempoa. Rumpukomppi alkaa heti noin 100 BPM:n perusnopeudella, joten ääntä kuuluu myös ennen kuin tempo on tunnistettu.")
                                HelpItem("Pysäytä", "Lopettaa mikrofonin kuuntelun ja rumpujen soiton.")
                                HelpItem("Rock / Blues / Metal", "Valitsee tyylikohtaisen kompin. Rockissa on suora peruskomppi, Bluesissa shuffle-henkinen svengi ja Metallissa tiheämpi bassorumpu sekä voimakkaammat iskut.")
                                HelpItem("Kappaleen osa", "Valitse Intro, Säkeistö, Kertosäe, Soolo, Välisoitto tai Lopetus. Valinta muuttaa kompin tiheyttä ja dynamiikkaa. Sovellus ei vielä tunnista kappaleen osia automaattisesti.")
                                HelpItem("Fillien määrä", "Säätää rumpufillien todennäköisyyttä. Suurempi prosentti lisää fillien esiintymistä; nolla vähentää niitä ja 100 % lisää niitä.")
                                HelpItem("Äänen ulostulo", "Automaattinen käyttää Androidin valitsemaa äänilaitetta. Puhelimen kaiutin ohjaa äänen puhelimen kaiuttimeen. Bluetooth ohjaa äänen yhdistettyyn Bluetooth-äänilaitteeseen, jos Android tarjoaa sen sovellukselle.")
                                HelpItem("Bluetooth-viive", "Bluetooth-äänessä voi olla viivettä. Kitaristin kanssa soitettaessa puhelimen oma kaiutin tai langallinen kuuloke on yleensä tarkempi vaihtoehto.")
                                HelpItem("Tempon tunnistus", "Soita selkeitä ja tasaisia iskuja mikrofonin lähellä. Usean iskun liukuva puskuri ja suodatus tasoittavat yksittäisiä virhetunnistuksia. Näytetty BPM on silti arvio.")
                            }
                        }
                    )
                }

                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("AI DRUMMER", style = MaterialTheme.typography.headlineLarge)
                        TextButton(onClick = { showHelp = true }) { Text("OHJE") }
                    }
                    Text("Kitaristin mukana soittava rumpaliprototyyppi · versio 0.3")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (running) "KUUNTELEE KITARAA · RUMPALI SOITTAA" else "VALMIINA", style = MaterialTheme.typography.titleMedium)
                            Text("$bpm BPM", style = MaterialTheme.typography.headlineMedium)
                            Text(if (tempoDetected) "Kitarasta tunnistettu tempo" else "Perusnopeus – tempoa ei vielä tunnistettu")
                            Text("Vinkki: soita selkeitä, tasaisia iskuja puhelimen mikrofonin lähellä.")
                        }
                    }
                    Button(onClick = {
                        if (running) engine.stop()
                        else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) engine.start()
                        else permission.launch(Manifest.permission.RECORD_AUDIO)
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "PYSÄYTÄ" else "ALOITA KUUNTELU") }

                    Text("Äänen ulostulo", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutputTarget.values().forEach { item ->
                            FilterChip(selected = output == item, onClick = { output = item; engine.setOutputTarget(item) }, label = { Text(item.label) })
                        }
                    }
                    Text(routeStatus, style = MaterialTheme.typography.bodySmall)

                    Text("Rumpalin tyyli", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DrumStyle.values().forEach { item -> FilterChip(selected = style == item, onClick = { style = item; engine.style = item }, label = { Text(item.label) }) }
                    }
                    Text("Kappaleen osa", style = MaterialTheme.typography.titleLarge)
                    Text("Voit ohjata rakennetta käsin. Automaattinen rakenteentunnistus ei ole vielä käytössä.")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Section.values().forEach { item ->
                            OutlinedButton(onClick = { section = item; engine.section = item }, modifier = Modifier.fillMaxWidth()) { Text(if (section == item) "● ${item.label}" else item.label) }
                        }
                    }
                    Text("Fillien määrä: ${(fillAmount * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
                    Slider(value = fillAmount, onValueChange = { fillAmount = it; engine.fillProbability = it }, valueRange = 0f..1f)
                    Text("Versio 0.3: vakaampi temposeuranta, monipuolisemmat rumpusoundit ja automaattiset fillit. Äänet tuotetaan edelleen sovelluksessa synteettisesti; luonnolliset rumpusamplet voidaan lisätä myöhemmin.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    override fun onDestroy() { if (::engine.isInitialized) engine.stop(); super.onDestroy() }
}

@Composable
private fun HelpItem(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(body, style = MaterialTheme.typography.bodySmall)
    }
}

enum class DrumStyle(val label: String) { ROCK("Rock"), BLUES("Blues"), METAL("Metal") }
enum class Section(val label: String) { INTRO("Intro"), VERSE("Säkeistö"), CHORUS("Kertosäe"), SOLO("Soolo"), BREAK("Välisoitto"), ENDING("Lopetus") }
enum class OutputTarget(val label: String) { AUTO("Automaattinen"), PHONE("Puhelin"), BLUETOOTH("Bluetooth") }

/** Microphone onset/tempo tracking and a pattern-based synthesized drum engine. */
class DrumEngine(context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile var isRunning = false; private set
    @Volatile var tempoBpm = 100; private set
    @Volatile var tempoDetected = false; private set
    @Volatile var routeStatus = "Automaattinen äänireititys"; private set
    @Volatile var style = DrumStyle.ROCK
    @Volatile var section = Section.VERSE
    @Volatile var fillProbability = 0.55f
    @Volatile private var outputTarget = OutputTarget.AUTO
    @Volatile private var currentTrack: AudioTrack? = null
    private var recorder: AudioRecord? = null
    private var inputThread: Thread? = null
    private var outputThread: Thread? = null
    private val sampleRate = 44100
    @Volatile private var lastOnsetNs = 0L
    @Volatile private var beatPeriodNs = 750_000_000L
    private val intervals = ArrayDeque<Long>()

    fun setOutputTarget(target: OutputTarget) {
        outputTarget = target
        applyOutputRoute(currentTrack)
    }

    @Synchronized fun start() {
        if (isRunning) return
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { routeStatus = "Mikrofonin alustaminen epäonnistui"; return }
        var r: AudioRecord? = null
        try {
            r = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192))
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); routeStatus = "Mikrofonia ei voitu käynnistää"; return }
            recorder = r
            tempoBpm = 80
            tempoDetected = false
            lastOnsetNs = 0L
            intervals.clear()
            beatPeriodNs = 750_000_000L
            isRunning = true
            r.startRecording()
            inputThread = Thread { analyzeLoop(r) }.also { it.start() }
            outputThread = Thread { drumLoop() }.also { it.start() }
        } catch (e: Exception) {
            isRunning = false
            try { r?.release() } catch (_: Exception) {}
            recorder = null
            routeStatus = "Äänen käynnistys epäonnistui: ${e.message ?: "tuntematon virhe"}"
        }
    }

    @Synchronized fun stop() {
        isRunning = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { inputThread?.join(700) } catch (_: Exception) {}
        try { outputThread?.join(700) } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        inputThread = null
        outputThread = null
    }

    /**
     * Detects guitar attacks from short RMS windows. A conservative refractory period
     * suppresses repeated peaks from string decay; beat candidates prefer a slower
     * pulse when one detected interval could be either a beat or a subdivision.
     */
    private fun analyzeLoop(r: AudioRecord) {
        val data = ShortArray(1024) // about 23 ms at 44.1 kHz
        var noiseFloor = 150.0
        var previousRms = 0.0
        var largeChangeCount = 0

        while (isRunning) {
            val n = r.read(data, 0, data.size)
            if (n <= 0) continue

            var sum = 0.0
            for (i in 0 until n) {
                val sample = data[i].toDouble()
                sum += sample * sample
            }
            val rms = sqrt(sum / n)

            // Track the background slowly and prevent a loud transient from raising it.
            if (rms < noiseFloor * 1.8) {
                noiseFloor = noiseFloor * 0.985 + rms * 0.015
            }
            val threshold = maxOf(420.0, noiseFloor * 2.7)
            val now = System.nanoTime()

            // Require a clear rise and at least 260 ms between attacks.
            if (rms > threshold &&
                previousRms <= threshold * 0.85 &&
                now - lastOnsetNs > 260_000_000L
            ) {
                val previousOnset = lastOnsetNs
                lastOnsetNs = now

                if (previousOnset > 0L) {
                    val rawInterval = now - previousOnset

                    // A guitarist may play quarter notes or subdivisions. Consider
                    // integer multiples only; do not manufacture a faster beat by
                    // halving an interval.
                    val candidates = (1L..4L)
                        .map { rawInterval * it }
                        .filter { it in 350_000_000L..1_500_000_000L }

                    if (candidates.isNotEmpty()) {
                        val currentPeriod = beatPeriodNs
                        val chosen = candidates.minWithOrNull(
                            compareBy<Long> {
                                kotlin.math.abs(
                                    kotlin.math.ln(it.toDouble() / currentPeriod.toDouble())
                                ) + if (it < currentPeriod) 0.10 else 0.0
                            }.thenByDescending { it }
                        )!!

                        intervals.addLast(chosen)
                        while (intervals.size >  9) intervals.removeFirst()

                        if (intervals.size >= 4) {
                            val sorted = intervals.sorted()
                            val median = sorted[sorted.size / 2]
                            val relativeChange =
                                kotlin.math.abs(median - beatPeriodNs).toDouble() / beatPeriodNs

                            if (relativeChange > 0.20) {
                                largeChangeCount++
                                if (largeChangeCount >= 4) {
                                    // Move toward a new tempo gradually, never jump to one transient.
                                    beatPeriodNs = (beatPeriodNs * 0.90 + median * 0.10).toLong()
                                    largeChangeCount = 0
                                }
                            } else {
                                largeChangeCount = 0
                                beatPeriodNs = (beatPeriodNs * 0.92 + median * 0.08).toLong()
                            }

                            tempoBpm = (60_000_000_000.0 / beatPeriodNs)
                                .toInt().coerceIn(40, 171)
                            tempoDetected = true
                        }
                    }
                }
            }
            previousRms = rms
        }
    }


    private fun findPreferredDevice(): AudioDeviceInfo? {
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        return when (outputTarget) {
            OutputTarget.AUTO -> null
            OutputTarget.PHONE -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            OutputTarget.BLUETOOTH -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
                ?: outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: if (Build.VERSION.SDK_INT >= 31) outputs.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
                } else null
        }
    }

    private fun applyOutputRoute(track: AudioTrack?) {
        if (track == null) return
        try {
            val device = findPreferredDevice()
            val accepted = track.setPreferredDevice(device)
            routeStatus = when (outputTarget) {
                OutputTarget.AUTO -> "Android valitsee äänilaitteen automaattisesti"
                OutputTarget.PHONE -> if (device != null && accepted) "Ääni ohjattu puhelimen kaiuttimeen" else "Puhelimen kaiutin ei ole valittavissa – käytetään Androidin oletusreittiä"
                OutputTarget.BLUETOOTH -> if (device != null && accepted) "Ääni ohjattu Bluetooth-laitteeseen" else "Bluetooth-äänilaitetta ei löytynyt – yhdistä laite ja valitse uudelleen"
            }
        } catch (_: Exception) {
            routeStatus = "Äänireitin vaihto ei onnistunut – käytetään Androidin oletusreittiä"
        }
    }

    /** 8th-note scheduler. The beat clock is buffered by a fixed look-ahead and never follows individual hits. */
    private fun drumLoop() {
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { routeStatus = "Äänilähdön alustaminen epäonnistui"; return }
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            routeStatus = "Rumpujen äänilähtöä ei voitu käynnistää: ${e.message ?: "virhe"}"
            return
        }
        if (track.state != AudioTrack.STATE_INITIALIZED) { track.release(); routeStatus = "Rumpujen äänilähtö ei alustunut"; return }
        currentTrack = track
        applyOutputRoute(track)
        track.play()

        val block = ShortArray(256)
        val kick = DrumVoice(sampleRate, DrumVoice.KICK)
        val snare = DrumVoice(sampleRate, DrumVoice.SNARE)
        val hat = DrumVoice(sampleRate, DrumVoice.HAT_CLOSED)
        val openHat = DrumVoice(sampleRate, DrumVoice.HAT_OPEN)
        val tomLow = DrumVoice(sampleRate, DrumVoice.TOM_LOW)
        val tomMid = DrumVoice(sampleRate, DrumVoice.TOM_MID)
        val tomHigh = DrumVoice(sampleRate, DrumVoice.TOM_HIGH)
        val crash = DrumVoice(sampleRate, DrumVoice.CRASH)
        val ride = DrumVoice(sampleRate, DrumVoice.RIDE)
        val voices = arrayOf(kick, snare, hat, openHat, tomLow, tomMid, tomHigh, crash, ride)
        var nextTick = System.nanoTime() + 250_000_000L
        var tick = 0L
        var fillThisBar = false
        var lastSection = section

        while (isRunning) {
            val now = System.nanoTime()
            val tickPeriod = (beatPeriodNs / 2L).coerceAtLeast(125_000_000L)
            if (now >= nextTick) {
                val tickInBar = (tick % 8L).toInt()
                val beatInBar = tickInBar / 2
                val phraseTick = (tick % 32L).toInt()
                val currentStyle = style
                val currentSection = section
                val energy = when (currentSection) {
                    Section.INTRO -> 0.62
                    Section.VERSE -> 0.82
                    Section.CHORUS -> 1.0
                    Section.SOLO -> 0.96
                    Section.BREAK -> 0.68
                    Section.ENDING -> 1.0
                }
                if (currentSection != lastSection) {
                    if (tickInBar == 0) crash.trigger(0.78 * energy)
                    lastSection = currentSection
                }
                if (phraseTick == 24) fillThisBar = Math.random() < fillProbability.toDouble()

                val inFill = fillThisBar && phraseTick in 28..31
                if (inFill) {
                    when (phraseTick) {
                        28 -> { kick.trigger(0.82 * energy); tomLow.trigger(0.78 * energy) }
                        29 -> tomMid.trigger(0.72 * energy)
                        30 -> { snare.trigger(0.88 * energy); tomHigh.trigger(0.78 * energy) }
                        31 -> { snare.trigger(0.96 * energy); crash.trigger(0.62 * energy) }
                    }
                } else {
                    // Eighth-note cymbal pulse, with style-specific accent and occasional open hat.
                    if (currentStyle == DrumStyle.BLUES) {
                        if (tickInBar % 2 == 0) ride.trigger((0.42 + if (beatInBar == 0) 0.12 else 0.0) * energy)
                        else hat.trigger(0.30 * energy)
                    } else {
                        val hatLevel = if (tickInBar % 2 == 0) 0.50 else 0.34
                        if (currentStyle == DrumStyle.METAL && tickInBar == 7 && currentSection == Section.CHORUS)
                            openHat.trigger(0.45 * energy)
                        else hat.trigger(hatLevel * energy)
                    }

                    if (tickInBar % 2 == 0) {
                        val kickLevel = when (currentStyle) {
                            DrumStyle.ROCK -> if (beatInBar == 0 || beatInBar == 2) 0.95 else 0.0
                            DrumStyle.BLUES -> if (beatInBar == 0 || beatInBar == 2) 0.82 else 0.0
                            DrumStyle.METAL -> if (beatInBar in 0..3) 0.92 else 0.0
                        }
                        val suppressForBreak = currentSection == Section.BREAK && beatInBar < 2
                        if (kickLevel > 0 && !suppressForBreak) kick.trigger(kickLevel * energy)

                        val snareBeat = beatInBar == 1 || beatInBar == 3
                        if (snareBeat && !(currentSection == Section.INTRO && beatInBar == 1)) {
                            snare.trigger((if (currentStyle == DrumStyle.BLUES) 0.78 else 0.92) * energy)
                        }
                        if (currentSection == Section.CHORUS && beatInBar == 0 && tick >= 32L) crash.trigger(0.72)
                        if (currentSection == Section.SOLO && beatInBar == 2) tomMid.trigger(0.34 * energy)
                        if (currentSection == Section.ENDING && beatInBar == 0) {
                            crash.trigger(0.95)
                            kick.trigger(1.0)
                        }
                    } else if (currentStyle == DrumStyle.METAL && (tickInBar == 1 || tickInBar == 5)) {
                        kick.trigger(0.68 * energy)
                    }
                }
                val swingFactor = if (currentStyle == DrumStyle.BLUES) {
                    if (tickInBar % 2 == 0) 1.20 else 0.80
                } else 1.0
                nextTick += (tickPeriod * swingFactor).toLong()
                if (nextTick < now - tickPeriod) nextTick = now + tickPeriod
                tick++
            }

            for (i in block.indices) {
                var x = 0.0
                for (voice in voices) x += voice.next()
                // Soft saturation prevents hard digital clipping when several voices overlap.
                x = x / (1.0 + kotlin.math.abs(x) * 0.75)
                block[i] = (x * 30000.0).toInt().coerceIn(-32767, 32767).toShort()
            }
            val written = track.write(block, 0, block.size)
            if (written < 0) break
        }
        try { track.stop() } catch (_: Exception) {}
        track.release()
        currentTrack = null
    }
}

/** Procedural drum voices: pitch envelopes, filtered noise and metallic partials. */
private class DrumVoice(private val rate: Int, private val kind: Int) {
    companion object {
        const val KICK = 1
        const val SNARE = 2
        const val HAT_CLOSED = 3
        const val HAT_OPEN = 4
        const val TOM_LOW = 5
        const val TOM_MID = 6
        const val TOM_HIGH = 7
        const val CRASH = 8
        const val RIDE = 9
    }
    private var phase = 0.0
    private var phase2 = 0.0
    private var age = 0
    private var length = 0
    private var level = 0.0
    private var noiseState = 0x13579BDF
    private var previousNoise = 0.0

    fun trigger(volume: Double) {
        age = 0
        phase = 0.0
        phase2 = 0.0
        previousNoise = 0.0
        length = when (kind) {
            KICK -> (rate * 0.24).toInt()
            SNARE -> (rate * 0.22).toInt()
            HAT_CLOSED -> (rate * 0.075).toInt()
            HAT_OPEN -> (rate * 0.42).toInt()
            TOM_LOW, TOM_MID, TOM_HIGH -> (rate * 0.30).toInt()
            CRASH -> (rate * 1.15).toInt()
            else -> (rate * 0.32).toInt()
        }
        level = volume.coerceIn(0.0, 1.0)
    }

    private fun noise(): Double {
        noiseState = noiseState * 1664525 + 1013904223
        return (((noiseState ushr 16) and 0x7fff) / 16384.0) - 1.0
    }

    fun next(): Double {
        if (age >= length || length == 0) return 0.0
        val t = age.toDouble() / rate
        val n = noise()
        val highNoise = n - previousNoise * 0.82
        previousNoise = n
        val value = when (kind) {
            KICK -> {
                val env = kotlin.math.exp(-t * 13.5)
                val freq = 155.0 * kotlin.math.exp(-t * 22.0) + 43.0
                phase += 2.0 * Math.PI * freq / rate
                val click = if (age < rate / 100) highNoise * (1.0 - age.toDouble() / (rate / 100)) * 0.20 else 0.0
                (kotlin.math.sin(phase) * env * 0.92 + click) * level
            }
            SNARE -> {
                val env = kotlin.math.exp(-t * 18.0)
                phase += 2.0 * Math.PI * 185.0 / rate
                (highNoise * env * 0.72 + kotlin.math.sin(phase) * env * 0.30) * level
            }
            HAT_CLOSED, HAT_OPEN, CRASH, RIDE -> {
                val decay = when (kind) { HAT_CLOSED -> 58.0; HAT_OPEN -> 10.5; CRASH -> 3.2; else -> 8.0 }
                val env = kotlin.math.exp(-t * decay)
                phase += 2.0 * Math.PI * 6150.0 / rate
                phase2 += 2.0 * Math.PI * 8430.0 / rate
                val metallic = kotlin.math.sin(phase) * 0.34 + kotlin.math.sin(phase2 * 1.31) * 0.25 + kotlin.math.sin(phase2 * 1.73) * 0.18
                val noiseMix = if (kind == RIDE) 0.25 else 0.62
                (metallic + highNoise * noiseMix) * env * level * when (kind) {
                    HAT_CLOSED -> 0.22
                    HAT_OPEN -> 0.25
                    CRASH -> 0.30
                    else -> 0.22
                }
            }
            TOM_LOW, TOM_MID, TOM_HIGH -> {
                val base = when (kind) { TOM_LOW -> 92.0; TOM_MID -> 132.0; else -> 178.0 }
                val env = kotlin.math.exp(-t * 9.0)
                val freq = base * kotlin.math.exp(-t * 5.0) + base * 0.42
                phase += 2.0 * Math.PI * freq / rate
                (kotlin.math.sin(phase) * env * 0.78 + highNoise * env * 0.08) * level
            }
            else -> 0.0
        }
        age++
        return value
    }
}
