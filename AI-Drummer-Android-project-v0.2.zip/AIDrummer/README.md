# AI Drummer – Android-prototyyppi 0.2

Tämä on Android-sovelluksen kehitysprototyyppi. Sovellus kuuntelee kitaraa puhelimen mikrofonilla, arvioi soiton tempoa ja tuottaa yksinkertaisen synteettisen rumpukompin.

## Tässä versiossa
- Rumpukomppi alkaa heti kuuntelun käynnistyessä noin 100 BPM:n perusnopeudella. Käyttäjän ei tarvitse odottaa tempon tunnistumista ennen kuin rumpuääni kuuluu.
- Kitaran iskujen perusteella arvioitu tempo päivittää rumpukompin nopeutta.
- Mikrofonitulossa käytetään Androidin tavallista MIC-lähdettä, jotta toiminta olisi laitteissa yhteensopivampaa kuin UNPROCESSED-lähteellä.
- Äänen ulostulon valinta: Automaattinen, Puhelin tai Bluetooth.
- Bluetooth-valinta käyttää Androidin tarjoamaa Bluetooth-äänilaitetta, jos sellainen on yhdistetty ja sovelluksen käytettävissä.
- Käyttöliittymässä on suomenkielinen OHJE, joka selittää kaikki painikkeet ja valinnat.
- Rock-, Blues- ja Metal-tyylit, kappaleen osan valinta sekä fillien määrän säätö.

## Käyttöohje
1. Yhdistä halutessasi Bluetooth-kaiutin tai -vahvistin puhelimen Android-asetuksista.
2. Avaa AI Drummer ja valitse Äänen ulostulo -kohdasta Automaattinen, Puhelin tai Bluetooth.
3. Paina ALOITA KUUNTELU ja hyväksy mikrofonilupa.
4. Rumpukomppi alkaa heti perusnopeudella. Soita selkeitä, tasaisia iskuja mikrofonin lähellä, jotta sovellus voi arvioida tempon.
5. Valitse rumpalin tyyli ja kappaleen osa. Säädä fillien määrää liukusäätimellä.
6. Paina PYSÄYTÄ lopettaaksesi kuuntelun ja rumpujen soiton.
7. Avaa OHJE-painike, jos tarvitset toimintojen tarkemmat selitykset.

## Äänen ulostulo ja viive
- **Automaattinen:** Android valitsee aktiivisen äänilaitteen järjestelmän reitityksen mukaisesti.
- **Puhelin:** sovellus pyytää äänen puhelimen sisäiseen kaiuttimeen.
- **Bluetooth:** sovellus pyytää äänen yhdistettyyn Bluetooth-äänilaitteeseen. Jos sopivaa laitetta ei löydy, Androidin oletusreitti jää käyttöön ja sovellus näyttää siitä ilmoituksen.
- Bluetooth voi lisätä huomattavan ääniviiveen. Kitaristin kanssa reaaliaikaisesti soitettaessa puhelimen kaiutin tai mahdollisimman viiveetön langallinen ulostulo on yleensä parempi.

## Tunnetut rajoitteet
Tämä ei ole vielä valmis älykäs virtuaalirumpali. Äänen voimakkuusmuutoksiin perustuva tunnistus on karkea ja voi tulkita väärin kitaran kieli-iskuja, sointujen vaihtoja tai ympäristön ääniä. Kun rumpuääni kuuluu samasta puhelimesta, se voi myös vaikuttaa mikrofonin tunnistukseen. Rumpuäänet ovat synteettisiä eivätkä vielä luonnollisia rumpusampleja. Kappaleen rakenne valitaan käsin; automaattista intro-/säkeistö-/kertosäetunnistusta ei ole.

## APK:n rakentaminen GitHub Actionsilla
1. Lataa ja pura ZIP-paketti.
2. Lataa puretun `AIDrummer`-kansion sisältö GitHub-repositorion juureen (myös `.github`-kansio).
3. Avaa GitHubin Actions-välilehti ja käynnistä **Build Android APK** -työnkulku.
4. Kun ajo onnistuu, avaa työnkulun ajo ja lataa APK kohdasta Artifacts.
5. Siirrä APK puhelimeen, avaa se ja hyväksy tarvittaessa sovellusten asennus kyseisestä lähteestä.

## Kehitysympäristö
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Android SDK 35
- Minimi Android 8.0 (API 26)
- Sovellustunnus: `com.example.aidrummer`
