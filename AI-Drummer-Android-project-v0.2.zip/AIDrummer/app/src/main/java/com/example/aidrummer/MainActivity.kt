package com.example.aidrummer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    private lateinit var engine: DrumEngine
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) engine.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DrumEngine(this)
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(false) }
                var bpm by remember { mutableIntStateOf(100) }
                var tempoDetected by remember { mutableStateOf(false) }
                var style by remember { mutableStateOf(DrumStyle.ROCK) }
                var section by remember { mutableStateOf(Section.VERSE) }
                var fillAmount by remember { mutableFloatStateOf(0.55f) }
                var output by remember { mutableStateOf(OutputTarget.AUTO) }
                var routeStatus by remember { mutableStateOf("Automaattinen äänireititys") }
                var showHelp by remember { mutableStateOf(false) }

                LaunchedEffect(Unit) {
                    while (true) {
                        bpm = engine.tempoBpm
                        running = engine.isRunning
                        tempoDetected = engine.tempoDetected
                        routeStatus = engine.routeStatus
                        delay(250)
                    }
                }

                if (showHelp) {
                    AlertDialog(
                        onDismissRequest = { showHelp = false },
                        confirmButton = { TextButton(onClick = { showHelp = false }) { Text("SULJE") } },
                        title = { Text("AI Drummer – käyttöohje") },
                        text = {
                            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                HelpItem("Aloita kuuntelu", "Pyytää mikrofoniluvan tarvittaessa. Sovellus kuuntelee kitaran iskuja ja arvioi niiden perusteella tempoa. Rumpukomppi alkaa heti noin 100 BPM:n perusnopeudella, joten ääntä kuuluu myös ennen kuin tempo on tunnistettu.")
                                HelpItem("Pysäytä", "Lopettaa mikrofonin kuuntelun ja rumpujen soiton.")
                                HelpItem("Rock / Blues / Metal", "Valitsee rumpukompin tyylin. Valinta vaikuttaa bassorummun ja muiden iskujen sijoitteluun.")
                                HelpItem("Kappaleen osa", "Valitse Intro, Säkeistö, Kertosäe, Soolo, Välisoitto tai Lopetus. Osa muuttaa kompin voimakkuutta ja fillien käyttäytymistä. Rakenne ei vielä tunnistu automaattisesti.")
                                HelpItem("Fillien määrä", "Säätää rumpufillien todennäköisyyttä. Suurempi prosentti lisää fillien esiintymistä; nolla vähentää niitä ja 100 % lisää niitä.")
                                HelpItem("Äänen ulostulo", "Automaattinen käyttää Androidin valitsemaa äänilaitetta. Puhelimen kaiutin ohjaa äänen puhelimen kaiuttimeen. Bluetooth ohjaa äänen yhdistettyyn Bluetooth-äänilaitteeseen, jos Android tarjoaa sen sovellukselle.")
                                HelpItem("Bluetooth-viive", "Bluetooth-äänessä voi olla viivettä. Kitaristin kanssa soitettaessa puhelimen oma kaiutin tai langallinen kuuloke on yleensä tarkempi vaihtoehto.")
                                HelpItem("Tempon tunnistus", "Soita selkeitä ja tasaisia iskuja mikrofonin lähellä. Näytetty BPM on arvio, eikä prototyyppi vielä tunnista tahtilajia tai kappaleen rakennetta luotettavasti.")
                            }
                        }
                    )
                }

                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("AI DRUMMER", style = MaterialTheme.typography.headlineLarge)
                        TextButton(onClick = { showHelp = true }) { Text("OHJE") }
                    }
                    Text("Kitaristin mukana soittava rumpaliprototyyppi")
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(if (running) "KUUNTELEE KITARAA · RUMPALI SOITTAA" else "VALMIINA", style = MaterialTheme.typography.titleMedium)
                            Text("$bpm BPM", style = MaterialTheme.typography.headlineMedium)
                            Text(if (tempoDetected) "Kitarasta tunnistettu tempo" else "Perusnopeus – tempoa ei vielä tunnistettu")
                            Text("Vinkki: soita selkeitä, tasaisia iskuja puhelimen mikrofonin lähellä.")
                        }
                    }
                    Button(onClick = {
                        if (running) engine.stop()
                        else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) engine.start()
                        else permission.launch(Manifest.permission.RECORD_AUDIO)
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (running) "PYSÄYTÄ" else "ALOITA KUUNTELU") }

                    Text("Äänen ulostulo", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutputTarget.values().forEach { item ->
                            FilterChip(selected = output == item, onClick = { output = item; engine.setOutputTarget(item) }, label = { Text(item.label) })
                        }
                    }
                    Text(routeStatus, style = MaterialTheme.typography.bodySmall)

                    Text("Rumpalin tyyli", style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DrumStyle.values().forEach { item -> FilterChip(selected = style == item, onClick = { style = item; engine.style = item }, label = { Text(item.label) }) }
                    }
                    Text("Kappaleen osa", style = MaterialTheme.typography.titleLarge)
                    Text("Voit ohjata rakennetta käsin. Automaattinen rakenteentunnistus ei ole vielä käytössä.")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Section.values().forEach { item ->
                            OutlinedButton(onClick = { section = item; engine.section = item }, modifier = Modifier.fillMaxWidth()) { Text(if (section == item) "● ${item.label}" else item.label) }
                        }
                    }
                    Text("Fillien määrä: ${(fillAmount * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
                    Slider(value = fillAmount, onValueChange = { fillAmount = it; engine.fillProbability = it }, valueRange = 0f..1f)
                    Text("Prototyyppi tunnistaa äänen voimakkuusmuutoksia ja tuottaa synteettisen rumpukompin. Kitaran tunnistus voi erehtyä, ja Bluetooth voi lisätä soittoon viivettä.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    override fun onDestroy() { if (::engine.isInitialized) engine.stop(); super.onDestroy() }
}

@Composable
private fun HelpItem(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(body, style = MaterialTheme.typography.bodySmall)
    }
}

enum class DrumStyle(val label: String) { ROCK("Rock"), BLUES("Blues"), METAL("Metal") }
enum class Section(val label: String) { INTRO("Intro"), VERSE("Säkeistö"), CHORUS("Kertosäe"), SOLO("Soolo"), BREAK("Välisoitto"), ENDING("Lopetus") }
enum class OutputTarget(val label: String) { AUTO("Automaattinen"), PHONE("Puhelin"), BLUETOOTH("Bluetooth") }

/** Microphone onset/tempo tracking and synthesized drum output. */
class DrumEngine(context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    @Volatile var isRunning = false; private set
    @Volatile var tempoBpm = 100; private set
    @Volatile var tempoDetected = false; private set
    @Volatile var routeStatus = "Automaattinen äänireititys"; private set
    @Volatile var style = DrumStyle.ROCK
    @Volatile var section = Section.VERSE
    @Volatile var fillProbability = 0.55f
    @Volatile private var outputTarget = OutputTarget.AUTO
    @Volatile private var currentTrack: AudioTrack? = null
    private var recorder: AudioRecord? = null
    private var inputThread: Thread? = null
    private var outputThread: Thread? = null
    private val sampleRate = 44100
    @Volatile private var lastOnsetNs = 0L
    @Volatile private var beatPeriodNs = 600_000_000L
    private val intervals = ArrayDeque<Long>()

    fun setOutputTarget(target: OutputTarget) {
        outputTarget = target
        applyOutputRoute(currentTrack)
    }

    @Synchronized fun start() {
        if (isRunning) return
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { routeStatus = "Mikrofonin alustaminen epäonnistui"; return }
        var r: AudioRecord? = null
        try {
            r = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 4096))
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); routeStatus = "Mikrofonia ei voitu käynnistää"; return }
            recorder = r
            tempoBpm = 100
            tempoDetected = false
            lastOnsetNs = 0L
            intervals.clear()
            beatPeriodNs = 600_000_000L
            isRunning = true
            r.startRecording()
            inputThread = Thread { analyzeLoop(r) }.also { it.start() }
            outputThread = Thread { drumLoop() }.also { it.start() }
        } catch (e: Exception) {
            isRunning = false
            try { r?.release() } catch (_: Exception) {}
            recorder = null
            routeStatus = "Äänen käynnistys epäonnistui: ${e.message ?: "tuntematon virhe"}"
        }
    }

    @Synchronized fun stop() {
        isRunning = false
        try { recorder?.stop() } catch (_: Exception) {}
        try { inputThread?.join(500) } catch (_: Exception) {}
        try { outputThread?.join(500) } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        inputThread = null
        outputThread = null
    }

    private fun analyzeLoop(r: AudioRecord) {
        val data = ShortArray(1024)
        var noiseFloor = 180.0
        var previousRms = 0.0
        while (isRunning) {
            val n = r.read(data, 0, data.size)
            if (n <= 0) continue
            var sum = 0.0
            for (i in 0 until n) { val v = data[i].toDouble(); sum += v * v }
            val rms = sqrt(sum / n)
            noiseFloor = noiseFloor * 0.985 + minOf(rms, noiseFloor * 1.5) * 0.015
            val now = System.nanoTime()
            val threshold = maxOf(420.0, noiseFloor * 2.0)
            if (rms > threshold && previousRms <= threshold && now - lastOnsetNs > 140_000_000L) {
                val prev = lastOnsetNs
                lastOnsetNs = now
                if (prev > 0) {
                    val raw = now - prev
                    val candidates = listOf(raw, raw * 2, raw * 3 / 2, raw / 2)
                    val plausible = candidates.filter { it in 250_000_000L..1_200_000_000L }
                    if (plausible.isNotEmpty()) {
                        val chosen = plausible.minByOrNull { abs(it - beatPeriodNs) } ?: plausible.first()
                        intervals.addLast(chosen)
                        while (intervals.size > 6) intervals.removeFirst()
                        val sorted = intervals.sorted()
                        beatPeriodNs = sorted[sorted.size / 2]
                        tempoBpm = (60_000_000_000.0 / beatPeriodNs).toInt().coerceIn(50, 240)
                        tempoDetected = true
                    }
                }
            }
            previousRms = rms
        }
    }

    private fun findPreferredDevice(): AudioDeviceInfo? {
        val outputs = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        return when (outputTarget) {
            OutputTarget.AUTO -> null
            OutputTarget.PHONE -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            OutputTarget.BLUETOOTH -> outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
                ?: outputs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                ?: if (Build.VERSION.SDK_INT >= 31) outputs.firstOrNull {
                    it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
                } else null
        }
    }

    private fun applyOutputRoute(track: AudioTrack?) {
        if (track == null) return
        try {
            val device = findPreferredDevice()
            val accepted = track.setPreferredDevice(device)
            routeStatus = when (outputTarget) {
                OutputTarget.AUTO -> "Android valitsee äänilaitteen automaattisesti"
                OutputTarget.PHONE -> if (device != null && accepted) "Ääni ohjattu puhelimen kaiuttimeen" else "Puhelimen kaiutin ei ole valittavissa – käytetään Androidin oletusreittiä"
                OutputTarget.BLUETOOTH -> if (device != null && accepted) "Ääni ohjattu Bluetooth-laitteeseen" else "Bluetooth-äänilaitetta ei löytynyt – yhdistä laite ja valitse uudelleen"
            }
        } catch (_: Exception) {
            routeStatus = "Äänireitin vaihto ei onnistunut – käytetään Androidin oletusreittiä"
        }
    }

    private fun drumLoop() {
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { routeStatus = "Äänilähdön alustaminen epäonnistui"; return }
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            routeStatus = "Rumpujen äänilähtöä ei voitu käynnistää: ${e.message ?: "virhe"}"
            return
        }
        if (track.state != AudioTrack.STATE_INITIALIZED) { track.release(); routeStatus = "Rumpujen äänilähtö ei alustunut"; return }
        currentTrack = track
        applyOutputRoute(track)
        track.play()
        val block = ShortArray(256)
        val kick = DrumVoice(sampleRate, 1)
        val snare = DrumVoice(sampleRate, 2)
        val hat = DrumVoice(sampleRate, 3)
        var nextBeat = System.nanoTime() + 200_000_000L
        var beat = 0L
        while (isRunning) {
            val now = System.nanoTime()
            val period = beatPeriodNs
            if (now >= nextBeat) {
                val barBeat = (beat % 4).toInt()
                val loud = if (section == Section.CHORUS || section == Section.SOLO) 1.0 else 0.78
                val isMetal = style == DrumStyle.METAL
                val isBlues = style == DrumStyle.BLUES
                if (barBeat == 0 || (isMetal && barBeat == 2)) kick.trigger(if (isMetal) 1.0 else loud)
                if (barBeat == 1 || barBeat == 3) snare.trigger(loud)
                if (isBlues && barBeat == 2) kick.trigger(0.65)
                hat.trigger(if (section == Section.INTRO) 0.35 else 0.55)
                val fillChance = fillProbability * if (section == Section.SOLO || section == Section.BREAK) 1.35f else 1f
                if (beat > 0 && beat % 16L == 15L && Math.random() < fillChance) snare.trigger(0.9)
                nextBeat += period
                if (nextBeat < now - period) nextBeat = now + period
                beat++
            }
            for (i in block.indices) {
                val x = (kick.next() + snare.next() + hat.next()).coerceIn(-1.0, 1.0)
                block[i] = (x * 26000).toInt().toShort()
            }
            val written = track.write(block, 0, block.size)
            if (written < 0) break
        }
        try { track.stop() } catch (_: Exception) {}
        track.release()
        currentTrack = null
    }
}

private class DrumVoice(private val rate: Int, private val kind: Int) {
    private var phase = 0.0
    private var age = 0
    private var length = 0
    private var level = 0.0
    fun trigger(volume: Double) { age = 0; phase = 0.0; length = when (kind) { 1 -> 9000; 2 -> 7500; else -> 3000 }; level = volume }
    fun next(): Double {
        if (age >= length || length == 0) return 0.0
        val t = age.toDouble() / rate
        val env = kotlin.math.exp(-t * when (kind) { 1 -> 13.0; 2 -> 22.0; else -> 48.0 })
        val value = if (kind == 1) {
            val f = 95.0 * kotlin.math.exp(-t * 9.0) + 42.0
            phase += 2.0 * Math.PI * f / rate
            kotlin.math.sin(phase) * env
        } else {
            phase += 2.0 * Math.PI * (if (kind == 2) 7300.0 else 10500.0) / rate
            (kotlin.math.sin(phase) * 0.55 + kotlin.math.sin(phase * 1.713) * 0.3) * env
        }
        age++
        return value * level * when (kind) { 1 -> 0.9; 2 -> 0.35; else -> 0.16 }
    }
}
